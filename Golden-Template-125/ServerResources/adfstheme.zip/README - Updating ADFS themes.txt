**********
README

If ADFS themse ever need updated, there are the primary files that might get updated.  Use the commands below
after changes to either of these files occur.  No restart is necessary after running these commands for the changes
to take effect

*********

Update the onload.js file

	Set-AdfsWebTheme -TargetName ADFSTheme -AdditionalFileResource @{Uri="/adfs/portal/script/onload.js";path="C:\adfstheme\<environmentfoldername>\script\onload.js"}
	Set-AdfsWebConfig -ActiveThemeName ADFSTheme

--------------------------------------------------------------------------

Update the logo file

	Set-AdfsWebTheme -TargetName ADFSTheme -Logo @{Locale="";path="C:\adfstheme\<environmentfoldername>\logo\logo.png"}
	Set-AdfsWebConfig -ActiveThemeName ADFSTheme

-------------------------------------------------------------------------------

Update the illustration file

	Set-AdfsWebTheme -TargetName ADFSTheme -Illustration @{path="c:\adfstheme\<environmentfoldername>\illustration\illustration.png"}  
	Set-AdfsWebConfig -ActiveThemeName ADFSTheme


-------------------------------------------------------------------------------

Update the css file

	Set-AdfsWebTheme -TargetName ADFSTheme -StyleSheet @{locale="";path="c:\adfstheme\<environmentfoldername>\css\style.css"}
	Set-AdfsWebConfig -ActiveThemeName ADFSTheme


-------------------------------------------------------------------------------

Set description text and copyright

	Set-AdfsGlobalWebContent -SignInPageDescriptionText "<p class='description-notice'>Notice: You have accessed a private computer system. This system is for authorized use only and user activities are monitored and recorded by company personnel. Unauthorized access to or use of this system is strictly prohibited and constitutes a violation of federal and state criminal and civil laws, including Title 18, Section 1030 of the United States Code and applicable international laws. Violators will be prosecuted to the fullest extent of the law. By logging on you certify that you have read and understand these items and that you are authorized to access and use this system.</p><br><p class='description-copyright'><strong>Copyright � 2019 -  - All Rights Reserved</strong></p>"
	Set-AdfsWebConfig -ActiveThemeName ADFSTheme

-------------------------------------------------------------------------------

Full update cheat sheet

WEBEX:
Set-AdfsWebTheme -TargetName ADFSTheme -AdditionalFileResource @{Uri="/adfs/portal/script/onload.js";path="C:\adfstheme\webex\script\onload.js"}
Set-AdfsWebTheme -TargetName ADFSTheme -AdditionalFileResource @{Uri="/adfs/portal/CiscoSansTTRegular.css";Path="C:\adfstheme\webex\css\CiscoSansTTRegular.woff"}
Set-AdfsWebTheme -TargetName ADFSTheme -AdditionalFileResource @{Uri="/adfs/portal/CiscoSansTTLight.css";Path="C:\adfstheme\webex\css\CiscoSansTTLight.woff"}
Set-AdfsWebTheme -TargetName ADFSTheme -AdditionalFileResource @{Uri="/adfs/portal/logoCisco.png";path="C:\adfstheme\webex\illustration\logoCisco.png"}
Set-AdfsWebTheme -TargetName ADFSTheme -AdditionalFileResource @{Uri="/adfs/portal/background.jpg";path="C:\adfstheme\webex\illustration\background.jpg"}
Set-AdfsWebTheme -TargetName ADFSTheme -Logo @{Locale="";path="C:\adfstheme\webex\logo\logo.png"}
Set-AdfsWebTheme -TargetName ADFSTheme -Illustration @{path="c:\adfstheme\webex\illustration\illustration.png"}
Set-AdfsGlobalWebContent -SignInPageDescriptionText "<img src='/adfs/portal/logoCisco.png' width='60.7px' height='32px'><p class='customDesc'>By using Webex Contact Center Enterprise, you accept the documented Terms of Service and Privacy Statements</p>";  
Set-AdfsWebTheme -TargetName ADFSTheme -StyleSheet @{locale="";path="c:\adfstheme\webex\css\style.css"}
Set-AdfsWebConfig -ActiveThemeName ADFSTheme

TELETECH:

Set-AdfsWebTheme -TargetName ADFSTheme -AdditionalFileResource @{Uri="/adfs/portal/script/onload.js";path="C:\adfstheme\teletech\script\onload.js"}
Set-AdfsWebTheme -TargetName ADFSTheme -Logo @{Locale="";path="C:\adfstheme\teletech\logo\logo.png"}
Set-AdfsWebTheme -TargetName ADFSTheme -Illustration @{path="c:\adfstheme\teletech\illustration\illustration.png"}  
Set-AdfsWebTheme -TargetName ADFSTheme -StyleSheet @{locale="";path="c:\adfstheme\teletech\css\style.css"}
Set-AdfsGlobalWebContent -SignInPageDescriptionText "<p class='description-notice'>Notice: You have accessed a private computer system. This system is for authorized use only and user activities are monitored and recorded by company personnel. Unauthorized access to or use of this system is strictly prohibited and constitutes a violation of federal and state criminal and civil laws, including Title 18, Section 1030 of the United States Code and applicable international laws. Violators will be prosecuted to the fullest extent of the law. By logging on you certify that you have read and understand these items and that you are authorized to access and use this system.</p><br><p class='description-copyright'><strong>Copyright � 2019 - All Rights Reserved</strong></p>"
Set-AdfsWebConfig -ActiveThemeName ADFSTheme

VERIZON:

Set-AdfsWebTheme -TargetName ADFSTheme -AdditionalFileResource @{Uri="/adfs/portal/script/onload.js";path="C:\adfstheme\verizon\script\onload.js"}
Set-AdfsWebTheme -TargetName ADFSTheme -Logo @{Locale="";path="C:\adfstheme\verizon\logo\logo.png"}
Set-AdfsWebTheme -TargetName ADFSTheme -Illustration @{path="c:\adfstheme\verizon\illustration\illustration.png"}  
Set-AdfsWebTheme -TargetName ADFSTheme -StyleSheet @{locale="";path="c:\adfstheme\verizon\css\style.css"}
Set-AdfsGlobalWebContent -SignInPageDescriptionText "<p class='description-notice'>Notice: You have accessed a private computer system. This system is for authorized use only and user activities are monitored and recorded by company personnel. Unauthorized access to or use of this system is strictly prohibited and constitutes a violation of federal and state criminal and civil laws, including Title 18, Section 1030 of the United States Code and applicable international laws. Violators will be prosecuted to the fullest extent of the law. By logging on you certify that you have read and understand these items and that you are authorized to access and use this system.</p><br><p class='description-copyright'><strong>Copyright � 2019 - All Rights Reserved</strong></p>"
Set-AdfsWebConfig -ActiveThemeName ADFSTheme

TELSTRA:

Set-AdfsWebTheme -TargetName ADFSTheme -AdditionalFileResource @{Uri="/adfs/portal/script/onload.js";path="C:\adfstheme\telstra\script\onload.js"}
Set-AdfsWebTheme -TargetName ADFSTheme -Logo @{Locale="";path="C:\adfstheme\telstra\logo\logo.png"}
Set-AdfsWebTheme -TargetName ADFSTheme -Illustration @{path="c:\adfstheme\telstra\illustration\illustration.png"}  
Set-AdfsWebTheme -TargetName ADFSTheme -StyleSheet @{locale="";path="c:\adfstheme\telstra\css\style.css"}
Set-AdfsGlobalWebContent -SignInPageDescriptionText "<p class='description-notice'>Notice: You have accessed a private computer system. This system is for authorized use only and user activities are monitored and recorded by company personnel. Unauthorized access to or use of this system is strictly prohibited and constitutes a violation of federal and state criminal and civil laws, including Title 18, Section 1030 of the United States Code and applicable international laws. Violators will be prosecuted to the fullest extent of the law. By logging on you certify that you have read and understand these items and that you are authorized to access and use this system.</p><br><p class='description-copyright'><strong>Copyright � 2019 - All Rights Reserved</strong></p>"
Set-AdfsWebConfig -ActiveThemeName ADFSTheme


