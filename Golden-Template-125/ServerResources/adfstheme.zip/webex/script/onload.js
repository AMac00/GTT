// Copyright (c) Microsoft Corporation.  All rights reserved.

// This file contains several workarounds on inconsistent browser behaviors that administrators may customize.
"use strict";

// iPhone email friendly keyboard does not include "\" key, use regular keyboard instead.
// Note change input type does not work on all versions of all browsers.
if (navigator.userAgent.match(/iPhone/i) != null) {
    var emails = document.querySelectorAll("input[type='email']");
    if (emails) {
        for (var i = 0; i < emails.length; i++) {
            emails[i].type = 'text';
        }
    }
}

// In the CSS file we set the ms-viewport to be consistent with the device dimensions, 
// which is necessary for correct functionality of immersive IE. 
// However, for Windows 8 phone we need to reset the ms-viewport's dimension to its original
// values (auto), otherwise the viewport dimensions will be wrong for Windows 8 phone.
// Windows 8 phone has agent string 'IEMobile 10.0'
if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
    var msViewportStyle = document.createElement("style");
    msViewportStyle.appendChild(
        document.createTextNode(
            "@-ms-viewport{width:auto!important}"
        )
    );
    msViewportStyle.appendChild(
        document.createTextNode(
            "@-ms-viewport{height:auto!important}"
        )
    );
    document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
}

// If the innerWidth is defined, use it as the viewport width.
if (window.innerWidth && window.outerWidth && window.innerWidth !== window.outerWidth) {
    var viewport = document.querySelector("meta[name=viewport]");
    viewport.setAttribute('content', 'width=' + window.innerWidth + 'px; initial-scale=1.0; maximum-scale=1.0');
}

// Gets the current style of a specific property for a specific element.
function getStyle(element, styleProp) {
    var propStyle = null;

    if (element && element.currentStyle) {
        propStyle = element.currentStyle[styleProp];
    }
    else if (element && window.getComputedStyle) {
        propStyle = document.defaultView.getComputedStyle(element, null).getPropertyValue(styleProp);
    }

    return propStyle;
}

// The script below is used for downloading the illustration image 
// only when the branding is displaying. This script work together
// with the code in PageBase.cs that sets the html inline style
// containing the class 'illustrationClass' with the background image.
var computeLoadIllustration = function () {
    var branding = document.getElementById("branding");
    var brandingDisplay = getStyle(branding, "display");
    var brandingWrapperDisplay = getStyle(document.getElementById("brandingWrapper"), "display");

    if (brandingDisplay && brandingDisplay !== "none" &&
        brandingWrapperDisplay && brandingWrapperDisplay !== "none") {
        var newClass = "illustrationClass";

        if (branding.classList && branding.classList.add) {
            branding.classList.add(newClass);
        } else if (branding.className !== undefined) {
            branding.className += " " + newClass;
        }
        if (window.removeEventListener) {
            window.removeEventListener('load', computeLoadIllustration, false);
            window.removeEventListener('resize', computeLoadIllustration, false);
        }
        else if (window.detachEvent) {
            window.detachEvent('onload', computeLoadIllustration);
            window.detachEvent('onresize', computeLoadIllustration);
        }
    }
};

if (window.addEventListener) {
    window.addEventListener('resize', computeLoadIllustration, false);
    window.addEventListener('load', computeLoadIllustration, false);
}
else if (window.attachEvent) {
    window.attachEvent('onresize', computeLoadIllustration);
    window.attachEvent('onload', computeLoadIllustration);
}

var loginMessage = document.getElementById('loginMessage');
if (loginMessage)
{
       // loginMessage element is present, modify its properties.
       loginMessage.innerHTML = 'Enter your username';
}

var userName = '';

if (typeof Login != 'undefined') {
	Login.submitLoginRequest = function () {
		var u = new InputUtil();
		var e = new LoginErrors();
		
		userName = document.getElementById(Login.userNameInput);
		var password = document.getElementById(Login.passwordInput);
		
		if (!userName.value) {
			u.setError(userName, 'Please enter your username');
			return false;
		}
		
		if (!password.value) {
			u.setError(password, e.passwordEmpty);
			return false;
		}

		
		if (userName.value && !userName.value.match('[@\\\\]')) {
			var userNameValue = 'hc031\\' + userName.value;
			document.forms['loginForm'].UserName.value = userNameValue;
		}
		
		document.forms['loginForm'].submit();
		return false;
	};
	
}


if (typeof UpdatePassword != 'undefined') {

	UpdatePassword.submitPasswordChange = function () {

		var u = new InputUtil();
		var e = new UpdErrors();

		userName = document.getElementById(UpdatePassword.userNameInput);
		var oldPassword = document.getElementById(UpdatePassword.oldPasswordInput);
		var newPassword = document.getElementById(UpdatePassword.newPasswordInput);
		var confirmNewPassword = document.getElementById(UpdatePassword.confirmNewPasswordInput);
		
		if (!userName.value) {
			u.setError(userName, 'Enter your username');
			return false;
		}

		if (!oldPassword.value) {
			u.setError(oldPassword, e.oldPasswordEmpty);
			return false;
		}

		if (!newPassword.value) {
			u.setError(newPassword, e.newPasswordEmpty);
			return false;
		}

		if (!confirmNewPassword.value) {
			u.setError(confirmNewPassword, e.confirmNewPasswordEmpty);
			return false;
		}

		if (newPassword.value !== confirmNewPassword.value) {
			u.setError(confirmNewPassword, e.mismatchError);
			return false;
		}

		if (userName.value.match(/@/g)) {
		
			var newUserName = userName.value.split('@')[0];
			var newDomainName = userName.value.split('@')[1];
			userName = newDomainName + '\\' + newUserName;
			document.forms['updatePasswordForm'].userNameInput.value = userName;
		} else if (userName.value && !userName.value.match('[@\\\\]')) {
			
			var userNameValue = 'hc031\\' + userName.value;
			document.forms['updatePasswordForm'].UserName.value = userNameValue
		}

		//var error = document.getElementById('error');
		//error.innerHTML= '';
		return true;
	};
}

var userNameInput = document.getElementById('userNameInput');
if (userNameInput)
{
// userNameInput element is present, modify its properties.
userNameInput.placeholder = 'Username';
}


var updateBoxDimension = function () {
	var $box = document.getElementById('contentWrapper');

	// To center the box
	/*var boxLeft = (window.innerWidth) / 2 - ($box.offsetWidth / 2),
		boxTop = (window.innerHeight) / 2 - ($box.offsetHeight / 2);

	$box.style.left = boxLeft + 'px';
	$box.style.top = boxTop + 'px';*/
	//$box.setAttribute("style","left:" + boxLeft + );
}

if (window.addEventListener) {
	window.addEventListener('resize', updateBoxDimension, false);
	window.addEventListener('load', updateBoxDimension, false);
}
else if (window.attachEvent) {
	window.attachEvent('onresize', updateBoxDimension);
	window.attachEvent('onload', updateBoxDimension);
}
